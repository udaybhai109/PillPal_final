
import { GoogleGenAI, Type } from "@google/genai";
import { ParseResult } from "../types";

export const parsePrescription = async (base64Image: string): Promise<ParseResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Image
          }
        },
        {
          text: "Analyze this image for ALL medications listed. For each one, extract: name, dosage, frequency, suggested times (HH:MM), duration, form (Pill, Liquid, etc.), and the medical condition it treats if visible. Return an array of medications."
        }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          medications: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                medication: { type: Type.STRING },
                dosage: { type: Type.STRING },
                frequency_per_day: { type: Type.NUMBER },
                times: { type: Type.ARRAY, items: { type: Type.STRING } },
                duration: { type: Type.STRING },
                form: { type: Type.STRING, description: "Must be one of: Pill, Injection, Liquid, Drops, Inhaler, Powder, Other" },
                condition: { type: Type.STRING },
                total_pills: { type: Type.NUMBER }
              },
              required: ["medication", "dosage", "frequency_per_day", "times", "duration", "form"]
            }
          }
        },
        required: ["medications"]
      }
    }
  });

  const jsonStr = response.text || '{"medications":[]}';
  return JSON.parse(jsonStr.trim());
};

export const checkInteractions = async (medNames: string[]): Promise<string | null> => {
  if (medNames.length < 2) return null;
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Check for major drug-drug interactions between these medications: ${medNames.join(', ')}. Provide a brief warning if any exist, or return 'None'.`,
  });
  const text = response.text;
  return text?.toLowerCase().includes('none') ? null : text;
};
